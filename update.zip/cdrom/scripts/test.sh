#/sbin/sh

echo "TEST SCRIPT!"
