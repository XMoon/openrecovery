#!/sbin/sh

#create the menu item
#echo "SD card utilities:scripted_menu:sdutil.menu:/app/sdutil/menu.sh" >> "$APP_MENU_FILE"
